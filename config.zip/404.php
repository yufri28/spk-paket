<!DOCTYPE html>
<html>

<head>
    <title>404 Page Not Found</title>
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>

<body>
    <h1>404 Page Not Found</h1>
    <p>The requested page could not be found.</p>
</body>

</html>